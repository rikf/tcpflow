/* Define to `unsigned long' if <sys/types.h> doesn't define.  */
#undef u_int32_t

/* Define to `unsigned short' if <sys/types.h> doesn't define.  */
#undef u_int16_t

/* Define to `unsigned char' if <sys/types.h> doesn't define.  */
#undef u_int8_t

/* Define to `unsigned char' if <sys/types.h> doesn't define.  */
#undef u_char

/* Define to `long' if <sys/types.h> doesn't define.  */
#undef fpos_t

/* Define if DLT_NULL is half-broken (see code for details) */
#undef DLT_NULL_BROKEN



